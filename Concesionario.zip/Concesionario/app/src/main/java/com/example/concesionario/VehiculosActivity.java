package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;


public class VehiculosActivity extends AppCompatActivity {
    EditText jetPlacaVh, jetMarcaVh, jetModeloVh, jetValorVh;
    Switch jswActivoVh;
    Button btnActivarVh;

    ClsOpenHelper admin = new ClsOpenHelper(this, "Concesionario.db", null, 1);
    long resp;
    String placa, marca, modelo, valor;
    int sw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehiculos);

        // Ocultar el titulo por defecto y asociar objetos Java con xml
        getSupportActionBar().hide();
        jetPlacaVh = findViewById(R.id.etPlacaVh);
        jetMarcaVh = findViewById(R.id.etMarcaVh);
        jetModeloVh = findViewById(R.id.etModeloVh);
        jetValorVh = findViewById(R.id.etValorVh);
        jswActivoVh = findViewById(R.id.swActivoVh);
        btnActivarVh = findViewById(R.id.btnActivarVh);
        jswActivoVh.setChecked(true);
        sw = 0;
        btnActivarVh.setEnabled(false);
    }

    public void Guardar(View view) {
        placa = jetPlacaVh.getText().toString();
        marca = jetMarcaVh.getText().toString();
        modelo = jetModeloVh.getText().toString();
        valor = jetValorVh.getText().toString();

        if (placa.isEmpty() || marca.isEmpty() || modelo.isEmpty() || valor.isEmpty()) {
            Toast.makeText(this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
            jetPlacaVh.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();
            registro.put("placa", placa);
            registro.put("marca", marca);
            registro.put("modelo", Integer.parseInt(modelo));
            registro.put("valor", Integer.parseInt(valor));
            if (sw == 0) {
                resp = db.insert("TblVehiculo", null, registro);
            } else {
                resp = db.update("TblVehiculo", registro, "placa='" + placa + "'", null);
                Limpiar_campos();
                sw = 0;
            }
            if (resp > 0) {
                Toast.makeText(this, "Registro Guardado", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
            } else {
                Toast.makeText(this, "Error Guardando Registro", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }

    public void Consultar(View view) {
        placa = jetPlacaVh.getText().toString();
        if (placa.isEmpty()) {
            Toast.makeText(this, "La placa es requerida", Toast.LENGTH_SHORT).show();
            jetPlacaVh.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor fila = db.rawQuery("select * from TblVehiculo where placa='" + placa + "'", null);
            if (fila.moveToNext()) {
                sw = 1;
                jetMarcaVh.setText(fila.getString(1));
                jetModeloVh.setText(fila.getString(2));
                jetValorVh.setText(fila.getString(3));
                if (fila.getString(4).equals("si")) {
                    jswActivoVh.setChecked(true);
                } else {
                    jswActivoVh.setChecked(false);
                    btnActivarVh.setEnabled(true);
                    btnActivarVh.setBackgroundColor(Color.rgb(255, 165, 0));
                }
            } else {
                Toast.makeText(this, "Vehiculo No Registrado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void Cancelar (View view) {
        Limpiar_campos();
    }

    public void Activar (View view) {
        SQLiteDatabase db = admin.getWritableDatabase();
        ContentValues registro = new ContentValues();
        registro.put("activo", "si");
        resp = db.update("TblVehiculo", registro, "placa='" + placa + "'", null);
        if (resp > 0) {
            Toast.makeText(this, "Vehiculo Activado Correctamente", Toast.LENGTH_SHORT).show();
            Limpiar_campos();
            btnActivarVh.setEnabled(false);
            btnActivarVh.setBackgroundColor(Color.rgb(193, 194, 197));
        } else {
            Toast.makeText(this, "Error al activar vehiculo", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    public void Anular (View view) {
        if (sw == 0) {
            Toast.makeText(this, "Primero debe consultar", Toast.LENGTH_SHORT).show();
            jetPlacaVh.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();
            registro.put("activo", "no");
            resp = db.update("Tblvehiculo", registro, "placa='" + placa + "'", null);
            if (resp > 0) {
                Toast.makeText(this, "Registro anulado correctamente", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
            } else {
                Toast.makeText(this, "Error al anular vehiculo", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }

    private void Limpiar_campos () {
        jetPlacaVh.setText("");
        jetMarcaVh.setText("");
        jetModeloVh.setText("");
        jetValorVh.setText("");
        jswActivoVh.setChecked(true);
        jetPlacaVh.requestFocus();
        sw = 0;
    }

    public void Back (View view) {
        Intent intmain = new Intent(this, MainActivity.class);
        startActivity(intmain);
    }
}