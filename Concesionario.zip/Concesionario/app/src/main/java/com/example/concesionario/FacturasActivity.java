package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class FacturasActivity extends AppCompatActivity {
    EditText jetCodFac, jetFecha, jetPlaca, jetPlacaVh;
    TextView jtvMarca, jtvModelo, jtvPrecio;
    Switch jswActivoFac, jswActivoVh;
    Button btnBuscar;

    ClsOpenHelper admin = new ClsOpenHelper(this, "Concesionario.db", null, 1);
    long respFac, resp;
    String cod, fecha, placa;
    int swVh, swC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facturas);

        // Ocultar el titulo por defecto y asociar objetos Java con xml
        getSupportActionBar().hide();
        jetCodFac = findViewById(R.id.etCodFac);
        jetFecha = findViewById(R.id.etFechaFac);
        jetPlaca = findViewById(R.id.etPlacaFac);
        jetPlacaVh = findViewById(R.id.etPlacaVh);
        jswActivoFac = findViewById(R.id.swActivoFac);
        jswActivoVh = findViewById(R.id.swActivoVh);
        btnBuscar = findViewById(R.id.btnBuscar);
        jtvMarca = findViewById(R.id.tvMarca);
        jtvModelo = findViewById(R.id.tvModelo);
        jtvPrecio = findViewById(R.id.tvPrecio);
        jswActivoFac.setChecked(true);
        jetPlaca.requestFocus();
        swVh = 0;
        swC = 0;
    }

    public void Buscar (View view) {
        placa = jetPlaca.getText().toString();
        SQLiteDatabase db = admin.getReadableDatabase();
        Cursor fila = db.rawQuery("select * from TblVehiculo where placa='" + placa + "'", null);
        if (fila.moveToNext()) {
            jtvMarca.setText(fila.getString(1));
            jtvModelo.setText(fila.getString(2));
            jtvPrecio.setText(fila.getString(3));
            jetCodFac.requestFocus();
            swVh = 1;
            if (fila.getString(4).equals("si")) {
                Toast.makeText(this, "Vehiculo Encontrado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "El vehiculo NO esta activo", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
                swVh = 0;
                jetPlaca.requestFocus();
            }
        } else {
            Toast.makeText(this, "Vehiculo No Registrado", Toast.LENGTH_SHORT).show();
            swVh = 0;
            Limpiar_campos();
        }
    }

    public void Guardar (View view) {
        placa = jetPlaca.getText().toString();
        cod = jetCodFac.getText().toString();
        fecha = jetFecha.getText().toString();

        if (placa.isEmpty() || cod.isEmpty() || fecha.isEmpty()) {
            Toast.makeText(this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
            jetPlaca.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registroFac = new ContentValues();
            ContentValues registro = new ContentValues();
            registroFac.put("cod_factura", cod);
            registroFac.put("fecha", fecha);
            registroFac.put("placa", placa);
            registro.put("activo", "no");
            if (swVh == 0) {
                Toast.makeText(this, "Debe generar la factura con un vehiculo que exista", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
                jetPlaca.requestFocus();
            } else {
                respFac = db.insert("TblFactura", null, registroFac);
                resp = db.update("Tblvehiculo", registro, "placa='" + placa + "'", null);
            }
            if (respFac > 0) {
                Toast.makeText(this, "Registro Guardado", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
                swVh = 0;
            } else {
                Toast.makeText(this, "Error Guardando Registro", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }

    public void Consultar(View view) {
        cod = jetCodFac.getText().toString();
        if (cod.isEmpty()) {
            Toast.makeText(this, "El numero de la factura es requerida", Toast.LENGTH_SHORT).show();
            jetCodFac.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor fila = db.rawQuery("select * from TblFactura where cod_factura='" + cod + "'", null);
            if (fila.moveToNext()) {
                swC = 1;
                jetFecha.setText(fila.getString(1));
                jetPlaca.setText(fila.getString(2));
                if (fila.getString(3).equals("si")) {
                    jswActivoFac.setChecked(true);
                } else {
                    jswActivoFac.setChecked(false);
                }
            } else {
                Toast.makeText(this, "Factura No Registrada", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void Anular (View view) {
        if (swC == 0) {
            Toast.makeText(this, "Primero debe consultar", Toast.LENGTH_SHORT).show();
            jetCodFac.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registroFac = new ContentValues();
            ContentValues registro = new ContentValues();
            registroFac.put("activo", "no");
            registro.put("activo", "si");
            respFac = db.update("TblFactura", registroFac, "cod_factura='" + cod + "'", null);
            resp = db.update("Tblvehiculo", registro, "placa='" + placa + "'", null);
            if (respFac > 0) {
                Toast.makeText(this, "Factura anulada correctamente", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
            } else {
                Toast.makeText(this, "Error al anular factura", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }


    public void Cancelar (View view) {
        Limpiar_campos();
    }

    private void Limpiar_campos () {
        jetPlaca.setText("");
        jetCodFac.setText("");
        jetFecha.setText("");
        jtvMarca.setText("");
        jtvPrecio.setText("");
        jtvModelo.setText("");
        jswActivoFac.setChecked(true);
        jetPlaca.requestFocus();
    }

    public void Back (View view) {
        Intent intmain = new Intent(this, MainActivity.class);
        startActivity(intmain);
    }
}